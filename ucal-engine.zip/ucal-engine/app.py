import streamlit as st
import time
import os
import psutil
import plotly.graph_objects as go
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor

st.set_page_config(page_title="UCAL Engine", layout="wide")

# ---------------- TASKS ----------------

def compute_task(x):
    total = 0
    for i in range(3000):   # balanced heaviness
        total += (x * i) ** 2
    return total

def data_task(x):
    total = 0
    for i in range(2000):
        total += (x + i) ** 2
    return total

def file_task(x):
    text = f"log_entry_{x} error warning info"
    return text.count("error") + text.count("warning")


# ---------------- SAFE WRAPPER ----------------
def process_chunk_wrapper(args):
    chunk, task_func = args
    for x in chunk:
        task_func(x)
    return None  # 🔥 avoid returning heavy results


# ---------------- CHUNKING ----------------
def chunkify(data, n_chunks):
    if n_chunks <= 0:
        n_chunks = 1

    k, m = divmod(len(data), n_chunks)
    chunks = []
    start = 0

    for i in range(n_chunks):
        size = k + (1 if i < m else 0)
        chunks.append(data[start:start + size])
        start += size

    return chunks


# ---------------- TASK DETECTION ----------------
def detect_task_type(task_func):
    sample = list(range(2000))

    start = time.time()
    for x in sample:
        task_func(x)
    end = time.time()

    avg = (end - start) / len(sample)

    if avg > 0.00004:
        return "CPU-BOUND"
    elif avg > 0.000015:
        return "MODERATE"
    else:
        return "LIGHT"


# ---------------- BASELINE ----------------
def run_baseline(data, task_func):
    start = time.time()
    for x in data:
        task_func(x)
    return time.time() - start


# ---------------- UCAL ENGINE ----------------
def run_ucal(data, task_func):
    num_workers = os.cpu_count()
    task_type = detect_task_type(task_func)

    # 🔥 SMART MODE SELECTION
    if task_type == "CPU-BOUND":
        mode = "multiprocessing"
        num_chunks = num_workers   # ⚡ reduced chunks (IMPORTANT)
    elif task_type == "MODERATE":
        mode = "threading"
        num_chunks = num_workers
    else:
        mode = "sequential"
        num_chunks = 1

    chunks = chunkify(data, num_chunks)
    args = [(chunk, task_func) for chunk in chunks]

    start = time.time()

    if mode == "multiprocessing":
        with ProcessPoolExecutor(max_workers=num_workers) as executor:
            list(executor.map(process_chunk_wrapper, args))

    elif mode == "threading":
        with ThreadPoolExecutor(max_workers=num_workers) as executor:
            list(executor.map(process_chunk_wrapper, args))

    else:
        for x in data:
            task_func(x)

    end = time.time()

    return end - start, mode, task_type


# ---------------- UI ----------------

st.title("⚡ UCAL - Adaptive CPU Acceleration Engine")
st.caption("Smart workload-aware optimization (CPU-only systems)")

# System Info
c1, c2, c3 = st.columns(3)
c1.metric("CPU Cores", os.cpu_count())
c2.metric("CPU Usage", f"{psutil.cpu_percent()}%")
c3.metric("RAM Usage", f"{psutil.virtual_memory().percent}%")

st.divider()

# Workload
task_ui = st.selectbox(
    "Select Workload",
    ["Heavy Computation", "Data Processing", "File Processing"]
)

if task_ui == "Heavy Computation":
    task_func = compute_task
elif task_ui == "Data Processing":
    task_func = data_task
else:
    task_func = file_task

# Size
size = st.slider("Workload Size", 10000, 150000, 60000, step=10000)

# Run
if st.button("🚀 Run UCAL"):

    data = list(range(size))

    progress = st.progress(0)
    st.subheader("⚙️ Running...")

    progress.progress(30)
    baseline_time = run_baseline(data, task_func)

    progress.progress(70)
    ucal_time, mode, detected = run_ucal(data, task_func)

    progress.progress(100)

    speedup = baseline_time / ucal_time

    st.success("✅ Done!")

    # Metrics
    m1, m2, m3 = st.columns(3)
    m1.metric("Baseline", f"{baseline_time:.2f}s")
    m2.metric("UCAL", f"{ucal_time:.2f}s")
    m3.metric("Speedup", f"{speedup:.2f}x 🚀")

    st.info(f"Detected: {detected}")
    st.info(f"Mode Used: {mode}")

    # Graph
    fig = go.Figure()
    fig.add_bar(x=["Baseline", "UCAL"], y=[baseline_time, ucal_time])
    st.plotly_chart(fig, use_container_width=True)

    # Insight
    st.subheader("🧠 Insight")

    if speedup > 2:
        st.success("Excellent CPU utilization 🚀")
    elif speedup > 1.3:
        st.warning("Moderate improvement ⚡")
    else:
        st.error("Overhead dominates (light workload)")