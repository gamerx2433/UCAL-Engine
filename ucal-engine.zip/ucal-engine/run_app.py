import subprocess
import sys
import os
import time
import socket

PORT = 8501

def is_port_open(port):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        return s.connect_ex(("localhost", port)) == 0

# 🔥 Get correct base path (works for both .py and .exe)
if getattr(sys, 'frozen', False):
    base_path = sys._MEIPASS
else:
    base_path = os.path.dirname(os.path.abspath(__file__))

app_path = os.path.join(base_path, "app.py")

# Start Streamlit
subprocess.Popen([
    sys.executable,
    "-m",
    "streamlit",
    "run",
    app_path,
    "--server.port", str(PORT),
    "--server.headless", "false"
])

# Wait for server
for _ in range(30):
    if is_port_open(PORT):
        break
    time.sleep(0.5)